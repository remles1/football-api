psql -h 0.0.0.0 -p 5432 -U postgres -d app -- polaczenie z baza danych z hosta
